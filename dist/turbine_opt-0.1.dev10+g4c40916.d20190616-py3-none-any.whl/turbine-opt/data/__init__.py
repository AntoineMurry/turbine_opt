from pkg_resources import resource_filename

DATA_SOURCE = resource_filename(__name__, '/')
